/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocisnerosparra;

/**
 *
 * @author Cisneros Oropeza
 */
public class Hormiga {
    protected int tamanoCamino;
    protected int camino[];
    protected boolean visitado[];

    public Hormiga(int tamanoRecor) 
    {
        this.tamanoCamino = tamanoRecor;
        this.camino = new int[tamanoRecor];
        this.visitado = new boolean[tamanoRecor];
    }
    protected void visitarCiudad(int indiceActual, int ciudad) 
    {
        camino[indiceActual + 1] = ciudad; //añade al camino
        visitado[ciudad] = true;           //actualiza bandera
    }

    protected boolean visitado(int i) 
    {
        return visitado[i];
    }

    protected double largoCamino(double grafo[][]) 
    {
        double largo = grafo[camino[tamanoCamino - 1]][camino[0]];
        for (int i = 0; i < tamanoCamino - 1; i++) 
            largo += grafo[camino[i]][camino[i + 1]];
        return largo;
    }

    protected void limpiar() 
    {
        for (int i = 0; i < tamanoCamino; i++)
            visitado[i] = false;
    }
    
    
}
