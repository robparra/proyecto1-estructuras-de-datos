/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectocisnerosparra;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Cisneros Oropeza
 */
public class Optimizacion {
    public String s="";
    private double c;             //numero de caminos
    private double alpha;           //importancia de las feromonas
    private double beta;            //prioridad de la distancia
    private double evaporacion;
    private double Q=1;             //feromonas dejadas en el camino por hormiga
    private double factorHor;     //numero de hormigas por nodo
    private double factorAlea; //introduciendo aleatoriedad

    private int iteracionesMax;

    private int numCiudades;
    private int numHormigas;
    private double grafo[][];
    private double caminos[][];
    private List<Hormiga> ants = new ArrayList<>();
    private Random random = new Random();
    private double probabilidades[];

    private int indiceActual;

    private int[] mejorRecorridoOrden;
    private double mejorRecorridoLargo;

    public Optimizacion(double tr, double al, double be, double ev, double q,double af, double rf, int iter, int numeroCiudades) 
    {
        c=tr; alpha=al; beta=be; evaporacion=ev; Q=q; factorHor=af; factorAlea=rf; iteracionesMax=iter;
                
        grafo = generarMatrizAleatoria(numeroCiudades);
        numCiudades = numeroCiudades;
        numHormigas = (int) (numCiudades * factorHor);

        caminos = new double[numCiudades][numCiudades];
        probabilidades = new double[numCiudades];
        
        for(int i=0;i<numHormigas;i++)
            ants.add(new Hormiga(numCiudades));
    }

    /**
     * Genera solucion inicial
     */
    public double[][] generarMatrizAleatoria(int n) 
    {
        double[][] matrizAleatoria = new double[n][n];
        
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<n;j++)
            {
                if(i==j)
                    matrizAleatoria[i][j]=0;
                else
                    matrizAleatoria[i][j]=Math.abs(random.nextInt(100)+1);
            }
        }
         
        s+=("\t");
        for(int i=0;i<n;i++)
            s+=(i+"\t");
        s+="\n";
        
        for(int i=0;i<n;i++)
        {
            s+=(i+"\t");
            for(int j=0;j<n;j++)
                s+=(matrizAleatoria[i][j]+"\t");
            s+="\n";
        }
        
        int sum=0;
        
        for(int i=0;i<n-1;i++)
            sum+=matrizAleatoria[i][i+1];
        sum+=matrizAleatoria[n-1][0];
        return matrizAleatoria;
    }

    /**
     * Realiza la optimizacion de la Hormiga
     */
    public void iniciarOptimizacion() 
    {
        for(int i=1;i<=5;i++)
        {
            s+=("\nIntento #" +i);
            resolver();
            s+="\n";
        }
    }

    public int[] resolver() 
    {
        acomodarHorm();
        limpiarCaminos();
        for(int i=0;i<iteracionesMax;i++)
        {
            moverHorm();
            actuaCaminos();
            actuaMejor();
        }
        s+=("\nLa Mejor Duración del Recorrido: " + (mejorRecorridoLargo - numCiudades));
        s+=("\nMejor Orden de Recorrido: " + Arrays.toString(mejorRecorridoOrden));
        return mejorRecorridoOrden.clone();
    }

    /**
     * Preparar Hormigas para la simulacion
     */
    private void acomodarHorm() 
    {
        for(int i=0;i<numHormigas;i++)
        {
            for(Hormiga ant:ants)
            {
                ant.limpiar();
                ant.visitarCiudad(-1, random.nextInt(numCiudades));
            }
        }
        indiceActual = 0;
    }

    /**
     * Con cada iteracion mueve las hormigas
     */
    private void moverHorm() 
    {
        for(int i=indiceActual;i<numCiudades-1;i++)
        {
            for(Hormiga ant:ants)
            {
                ant.visitarCiudad(indiceActual,selecSiguiCiu(ant));
            }
            indiceActual++;
        }
    }

    /**
     * Selecciona la siguiente ciudad para cada Hormiga
     */
    private int selecSiguiCiu(Hormiga ant) 
    {
        int t = random.nextInt(numCiudades - indiceActual);
        if (random.nextDouble() < factorAlea) 
        {
            int indiceCiud=-999;
            for(int i=0;i<numCiudades;i++)
            {
                if(i==t && !ant.visitado(i))
                {
                    indiceCiud=i;
                    break;
                }
            }
            if(indiceCiud!=-999)
                return indiceCiud;
        }
        calculaProbabilidades(ant);
        double r = random.nextDouble();
        double total = 0;
        for (int i = 0; i < numCiudades; i++) 
        {
            total += probabilidades[i];
            if (total >= r) 
                return i;
        }
        throw new RuntimeException("No hay mas Ciudades");
    }

    /**
     * Calcula las siguientes probabilidades de selección de ciudades
     */
    public void calculaProbabilidades(Hormiga ant) 
    {
        int i = ant.camino[indiceActual];
        double feromona = 0.0;
        for (int l = 0; l < numCiudades; l++) 
        {
            if (!ant.visitado(l)) 
                feromona += Math.pow(caminos[i][l], alpha) * Math.pow(1.0 / grafo[i][l], beta);
        }
        for (int j = 0; j < numCiudades; j++) 
        {
            if (ant.visitado(j)) 
                probabilidades[j] = 0.0;
            else 
            {
                double numerador = Math.pow(caminos[i][j], alpha) * Math.pow(1.0 / grafo[i][j], beta);
                probabilidades[j] = numerador / feromona;
            }
        }
    }

    /**
     * Actualiza caminos que utilizaron las hormigas
     */
    private void actuaCaminos() 
    {
        for (int i = 0; i < numCiudades; i++) 
        {
            for (int j = 0; j < numCiudades; j++) 
                caminos[i][j] *= evaporacion;
        }
        for (Hormiga a : ants) 
        {
            double contribucion = Q / a.largoCamino(grafo);
            for (int i = 0; i < numCiudades - 1; i++)
                caminos[a.camino[i]][a.camino[i + 1]] += contribucion;
            caminos[a.camino[numCiudades - 1]][a.camino[0]] += contribucion;
        }
    }

    /**
     * Actualiza la mejor solucion
     */
    private void actuaMejor() 
    {
        if (mejorRecorridoOrden == null) 
        {
            mejorRecorridoOrden = ants.get(0).camino;
            mejorRecorridoLargo = ants.get(0).largoCamino(grafo);
        }
        
        for (Hormiga a : ants) 
        {
            if (a.largoCamino(grafo) < mejorRecorridoLargo) 
            {
                mejorRecorridoLargo = a.largoCamino(grafo);
                mejorRecorridoOrden = a.camino.clone();
            }
        }
    }

    /**
     * Limpia caminos depues de la simulacion
     */
    private void limpiarCaminos() 
    {
        for(int i=0;i<numCiudades;i++)
        {
            for(int j=0;j<numCiudades;j++)
                caminos[i][j]=c;
        }
    }
}
